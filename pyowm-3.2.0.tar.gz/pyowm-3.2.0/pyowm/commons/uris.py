#!/usr/bin/env python
# -*- coding: utf-8 -*-

ROOT_GEOCODING_API_URL = 'openweathermap.org/geo/1.0'
DIRECT_GEOCODING_URI = 'direct'
REVERSE_GEOCODING_URI = 'reverse'

